# student-grade-predictor

In order to learn a bit more about Machine Learning, this repository contains a small program written in Python that predicts the 3rd grade of math students given a few values (including the 1st and 2nd grades).

The model used is **Linear Regression**.